<?php

//Agregar productos

include('db.php');
include('function.php');
if(isset($_POST["operation"]))
{
   if($_POST["operation"] == "Add")
   {
      $image = '';
      if($_FILES["producto_image"]["name"] != '')
      {
         $image = upload_image();
     }
     $statement = $connection->prepare("
         INSERT INTO productos (nombre, precio, imagen) 
         VALUES (:nombre, :precio, :imagen)
         ");
     $result = $statement->execute(
         array(
            ':nombre' => $_POST["nombre"],
            ':precio' => $_POST["precio"],
            ':imagen'  => $image
        )
     );
     if(!empty($result))
     {
         echo 'Producto Agregado';
     }
 }
 //Editar un registro
 if($_POST["operation"] == "Edit")
 {
  $image = '';
  if($_FILES["producto_image"]["name"] != '')
  {
     $image = upload_image();
 }
 else
 {
     $image = $_POST["hidden_producto_image"];
 }
 $statement = $connection->prepare(
     "UPDATE productos 
     SET nombre = :nombre, precio = :precio, imagen = :imagen  
     WHERE id = :id
     "
 );
 $result = $statement->execute(
     array(
        ':nombre' => $_POST["nombre"],
        ':precio' => $_POST["precio"],
        ':imagen'  => $image,
        ':id'   => $_POST["prod_id"]
    )
 );
 if(!empty($result))
 {
     echo 'Producto Actualizado';
 }
}
}

?>