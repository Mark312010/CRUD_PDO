<?php
include('db.php');
include('function.php');
if(isset($_POST["prod_id"]))
{
   $output = array();
   $statement = $connection->prepare(
      "SELECT * FROM productos 
      WHERE id = '".$_POST["prod_id"]."' 
      LIMIT 1"
  );
   $statement->execute();
   $result = $statement->fetchAll();
   foreach($result as $row)
   {
      $output["nombre"] = $row["nombre"];
      $output["precio"] = $row["precio"];
      if($row["imagen"] != '')
      {
         $output['producto_image'] = '<img src="upload/'.$row["imagen"].'" class="img-thumbnail" width="50" height="35" /><input type="hidden" name="hidden_producto_image" value="'.$row["imagen"].'" />';
     }
     else
     {
         $output['producto_image'] = '<input type="hidden" name="hidden_producto_image" value="" />';
     }
 }
 echo json_encode($output);
}
?>