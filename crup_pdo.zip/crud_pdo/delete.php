<?php

//Eliminar un registro

include('db.php');
include("function.php");

if(isset($_POST["prod_id"]))
{
   $image = get_image_name($_POST["prod_id"]);
   if($image != '')
   {
      unlink("upload/" . $image);
  }
  $statement = $connection->prepare(
      "DELETE FROM productos WHERE id = :id"
  );
  $result = $statement->execute(
      array(
         ':id' => $_POST["prod_id"]
     )
  );

  if(!empty($result))
  {
      echo 'Producto Eliminado';
  }
}



?>